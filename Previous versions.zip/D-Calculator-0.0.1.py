import math as m
print("——————复数Z=a+bi的n次方根求解——————")
print("———————————a,b∈R;n∈N*———————————")
a=input("a=")
b=input("b=")
n=input("n=")
try:
    a=float(a)
    try:
        b=float(b)
        try:
            n=int(n)
            if n>0:
                r=pow((pow(a,2)+pow(b,2)),0.5)
                if r==0:
                    print("0","的",n,"次方根为:")
                    print("—————————————————————————————————")
                    print("Zn=","0")
                else:
                    arg=m.acos(a/r)
                    if b/r<0:
                        arg=2*m.pi-arg
                    at=str(a)
                    opb=str(b)+"i"
                    if n==2:
                       if a==0:
                        print(opb,"的平方根为:")
                       else:
                            if b<0:
                                print(at+opb,"的平方根为:")
                            elif b>0:
                                print(at+"+"+opb,"的平方根为:")
                            else:
                                print(at,"的平方根为:")
                    elif n>3:
                        if a==0:
                            print(opb,"的",n,"次方根为:")
                        else:
                            if b<0:
                                print(at+opb,"的",n,"次方根为:")
                            elif b>0:
                                print(at+"+"+opb,"的",n,"次方根为:")
                            else:
                                print(at,"的",n,"次方根为:")
                    elif n==3:
                        if a==0:
                            print(opb,"的立方根为:")
                        else:
                            if b<0:
                                print(at+opb,"的立方根为:")
                            elif b>0:
                                print(at+"+"+opb,"的立方根为:")
                            else:
                                print(at,"的立方根为:")
                    print("—————————————————————————————————")
                    k=0
                    rn=pow(r,1/n)
                    while k<=n-1:
                        an=round(rn*m.cos((2*m.pi*k+arg)/n),3)
                        bn=round(rn*m.sin((2*m.pi*k+arg)/n),3)
                        ant=str(an)
                        opbn=str(bn)+"i"
                        opZ="Z"+str(k+1)+"="
                        if an==0:
                            print(opZ,opbn)
                        else:
                            if bn<0:
                                print(opZ,ant+opbn)
                            elif bn>0:
                                print(opZ,ant+"+"+opbn)
                            else:
                                print(opZ,ant)
                        k=k+1
            else:
                print("请重新输入n,n∈N*")
        except:
            print("请重新输入n,n∈N*")
    except:
        print("请重新输入b,b∈R")
except:
    print("请重新输入a,a∈R")
print("—————————————————————————————————")
input("感谢使用")
