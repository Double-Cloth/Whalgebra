def BT(Ba,Bb,Bn):
    R=C=0
    RE=[]
    for i in range(0,Bn+1):
        add=(Bb**i)*(Ba**(Bn-i))*(FA(Bn)/(FA(i)*FA(Bn-i)))
        if i%4==0:
            R=R+add
        elif i%4==2:
            R=R-add
        elif i%4 ==3:
            C=C-add
        else:
            C=C+add
    RE.append(R)
    RE.append(C)
    return(RE)
def arccos(x):
    arc=0
    dt=1
    for i in range(1,11):
        if dt==1:
            while dt==1:
                if cos(arc)>x:
                    arc=arc+pi/(10**i)
                else:
                    dt=0
        if dt==0:
            while dt==0: 
                if cos(arc)<x:
                    arc=arc-pi/(10**i)
                else:
                    dt=1
    return(arc)
def small(x):
    while x>2*pi:
        x=x-2*pi
    return(x)       
def cos(x):
    ox=0
    x=small(x)
    for i in range(0,16):
        ox=ox+pow(-1,i)*pow(x,2*i)/FA(2*i)
    return(ox)
def sin(x):
    ox=0
    x=small(x)
    for i in range(0,16):
        ox=ox+pow(-1,i)*pow(x,2*i+1)/FA(2*i+1)
    return(ox)
def FA(x):
    if x==0:
        return(1)
    else:
        kx=x
        for i in range(1,x):
            x=x*(kx-i)
    return(x)
def nan(nan):
    return not float('-inf')<nan<float('inf')
def ln(x):
    if abs(x)>=e**600:
        return (float("nan"))
    else:
        dt=0
        ln=-600
        for i in range(0,11):
            if dt==0:
                while dt==0:
                    if e**ln<x:
                        ln=ln+100/(10**i)
                    else:
                        dt=1
            elif dt==1:
                while dt==1:
                    if e**ln>x:
                        ln=ln-100/(10**i)
                    else:
                        dt=0
        return (ln)
def QM(r2,n):
    MG=[]
    if r2>7.2*10*11:
        oA=round(pow(r2,1/n),s)
        MG.append(oA)
        MG.append(1)
    else:
        r2=round(r2, 4)
        I=2
        c2=0
        C=1
        while r2%1!=0:
            r2=r2*10
            r2=round(r2,4)
            c2=c2+1
        un=r2*(10**c2)
        r2=un
        while I**n<=un:
            if r2%(I**n)==0:
                C=C*I
                r2=r2/(I**n)
                I=2
            else:
                I=I+1
        C=C/(10**c2)
        MG.append(C)
        MG.append(r2)
    return(MG)
ppii=['1','4','1','5','9','2','6','5','3']
pi=TD=3.1415926535897932384626433832795
e=inputs=2.71828182845904523536028747135266
print("———————————复数的运算———————————")
while inputs!=0:
    s=input("请输入保留小数位数(支持保留[1,9]位小数):")
    try:
        s=int(s)
        if s<1 or s>9:
            print("仅支持保留[1,9]位小数")
        else:
            inputs=0
            baopi="3."
            for bao in range(0,s):
                baopi=baopi+ppii[bao]
            print("注意:输出值为近似值,若出现不正常的结果,可能是输出数值太小")
            print("—————————————————————————————————")
            print("模式'0':退出")
            print("模式'1':复数一般形式转化为极坐标形式")
            print("模式'2':复数极坐标形式转化为一般形式")
            print("模式'3':复数的n次幂计算")
            print("模式'4':复数的n次方根求解")
            print("—————————————————————————————————")
            while TD>2:
                mode=input("请选择模式:")
                if mode=="0":
                    TD=0.30103
                elif mode=="1":
                    print("——————Z=a+bi▶Z=r∠θ——————")
                    print("—————————a,b∈R—————————")
                    a=input("a=")
                    b=input("b=")
                    try:
                        a=float(a)
                        try:
                            b=float(b)
                            try:
                                print("—————————————————————————————————")
                                r=pow((pow(a,2)+pow(b,2)),0.5)
                                if r==0:
                                    print(0,"=",0)
                                else:
                                    arg=arccos(a/r)
                                    if b/r<0:
                                        arg=-arg
                                    oarg=str(round(arg,s))
                                    r2=r**2
                                    C=QM(r2,2)[0]
                                    r2=QM(r2,2)[1]
                                    if nan(C) or nan(r2)==True:
                                        print("输入的复数模太大,无法计算,请重新输入模较小的复数")
                                    else:
                                        if C==1:
                                            if r2==1:
                                                oA=" 1"
                                            else:
                                                oA=" √("+str(r2)+")"
                                        else:
                                            if r2==1:
                                                oA=" "+str(C)
                                            else:
                                                oA=" "+str(C)+"√("+str(r2)+")"
                                        oa=str(a)
                                        ob=str(b)+"i"
                                        if a==0:
                                            print(ob,"=",end="")
                                        else:
                                            if b<0:
                                                print(oa+ob,"=",end="")
                                            elif b>0:
                                                print(oa+"+"+ob,"=",end="")
                                            else:
                                                print(oa,"=",end="")
                                        if arg==0:
                                            print(oA)
                                        else:
                                            print(oA+"∠"+oarg)
                            except:
                                print("输入的复数模太大,无法计算,请重新输入模较小的复数")
                        except:
                            print("请重新输入b,b∈R")
                    except:
                        print("请重新输入a,a∈R")
                    print("—————————————————————————————————")
                elif mode=="2":
                    print("————————Z=r∠θ▶Z=a+bi————————")
                    print("———r∈[0,+∞);|θ|∈[0,"+baopi+"]———")
                    r=input("r=")
                    ct=input("θ=")
                    try:
                        r=float(r)
                        try:
                            ct=float(ct)
                            try:
                                if r<0:
                                    print("请重新输入r,r∈[0,+∞)")
                                elif abs(ct)>float(baopi):
                                    print("请重新输入θ,|θ|∈[0,"+baopi+"]")
                                else:
                                    print("—————————————————————————————————")
                                    if r**2+ct**2==0:
                                        print("0=","0")
                                    else:
                                        kct=ct
                                        ct=abs(ct)
                                        if 0<=ct<=0.5*pi:
                                            a=r*cos(ct)
                                            b=r*sin(ct)
                                        else:
                                            ct=pi-ct
                                            a=-r*cos(ct)
                                            b=r*sin(ct)
                                        if kct<0:
                                            b=-b
                                        a=round(a,s)
                                        b=round(b,s)
                                        if nan(a) or nan(b)==True:
                                            print("输入的复数模太大,无法计算,请重新输入模较小的复数")
                                        else:
                                            if ct==0:
                                                print(str(r)+"=",end="")
                                            else:
                                                print(str(r)+"∠"+str(kct)+"=",end="")
                                            oa=str(a)
                                            ob=str(b)+"i"
                                            if a==0:
                                                print("",ob)
                                            else:
                                                if b<0:
                                                    print("",oa+ob)
                                                elif b>0:
                                                    print("",oa+"+"+ob)
                                                else:
                                                    print("",oa)
                            except:
                                print("输入的复数模太大,无法计算,请重新输入模较小的复数")
                        except:
                            print("请重新输入θ,|θ|∈[0,"+baopi+"]")
                    except:
                        print("请重新输入r,r∈[0,+∞)")
                    print("—————————————————————————————————")
                elif mode=="3":
                    print("  子模式'1':复数的实数次方计算")
                    print("  子模式'2':复数的复数次方计算")
                    modeson=input("  请选择子模式:")
                    if modeson=="1":
                        print("——————复数Z=a+bi的n次方计算——————")
                        print("—————————a,b∈R;n∈Z—————————")
                        a=input("a=")
                        b=input("b=")
                        n=input("n=")
                        try:
                            a=float(a)
                            try:
                                b=float(b)
                                try:
                                    n=int(n)
                                    try:
                                        print("—————————————————————————————————")
                                        r2=a**2+b**2
                                        if r2==0:
                                            print("0","的",n,"次方为","0")
                                        else:
                                            RA=BT(a,b,abs(n))[0]
                                            CB=BT(a,b,abs(n))[1]
                                            if n<0:
                                                R2=RA**2+CB**2
                                                RA=RA/(R2)
                                                CB=-CB/(R2)
                                            OAR=str(round(RA,s))
                                            OBC=str(round(CB,s))+"i"
                                            if nan(RA) or nan(CB)==True:
                                                print("输入的复数模太大或|n|太大,无法计算,请重新输入模较小的复数或较小的|n|")
                                            else:
                                                oa=str(a)
                                                ob=str(b)+"i"
                                                if a==0:
                                                    print(ob,"的",n,"次方为:",end="")
                                                else:
                                                    if b<0:
                                                        print(oa+ob,"的",n,"次方为:",end="")
                                                    elif b>0:
                                                        print(oa+"+"+ob,"的",n,"次方为:",end="")
                                                    else:
                                                        print(oa,"的",n,"次方为:",end="")
                                                if round(RA,s)==0:
                                                    if round(CB,s)==0:
                                                        print("",0)
                                                    else:
                                                        print("",OBC)
                                                else:
                                                    if round(CB,s)<0:
                                                        print("",OAR+OBC)
                                                    elif round(CB,s)>0:
                                                        print("",OAR+"+"+OBC)
                                                    else:
                                                        print("",OAR)
                                    except:
                                        print("输入的复数模太大或|n|太大,无法计算,请重新输入模较小的复数或较小的|n|")
                                except:
                                    print("请重新输入n,n∈Z")
                            except:
                                print("请重新输入b,b∈R")
                        except:
                            print("请重新输入a,a∈R")
                        print("—————————————————————————————————")
                    elif modeson=="2":
                        print("——————复数Z=a+bi的n=c+di次方计算——————")
                        print("—————————a,b,c∈R;d∈R*—————————")
                        a=input("a=")
                        b=input("b=")
                        c=input("c=")
                        d=input("d=")
                        try:
                            a=float(a)
                            try:
                                b=float(b)
                                try:
                                    c=float(c)
                                    try:
                                        d=float(d)
                                        if d==0:
                                            print("请重新输入d,d∈R*")
                                        else:
                                            try:
                                                print("—————————————————————————————————")
                                                r=pow(a**2+b**2,0.5)
                                                oc=str(c)
                                                od=str(d)+"i"
                                                if r==0:
                                                    print("0 的",end="")
                                                    if c==0:
                                                        print(od,"次方为 0")
                                                    else:
                                                        if d<0:
                                                            print(oc+od,"次方为 0")
                                                        elif d>0:
                                                            print(oc+"+"+od,"次方为 0")
                                                        else:
                                                            print(oc,"次方为 0")
                                                else:
                                                    arg=arccos(a/r)
                                                    if b/r<0:
                                                        arg=-arg
                                                    _rn=(r**c/e**(d*arg))
                                                    _ac=cos(d*ln(r)+c*arg)
                                                    _as=sin(d*ln(r)+c*arg)
                                                    if nan(r) or nan(_rn) or nan(_ac) or nan(_as)==True:
                                                        print("输入的复数模太大,无法计算,请重新输入模较小的复数")
                                                    else:
                                                        oa=str(a)
                                                        ob=str(b)+"i"
                                                        if a==0:
                                                            print(ob,"的 ",end="")
                                                        else:
                                                            if b<0:
                                                                print(oa+ob,"的 ",end="")
                                                            elif b>0:
                                                                print(oa+"+"+ob,"的 ",end="")
                                                            else:
                                                                print(oa,"的 ",end="")
                                                        if c==0:
                                                            print(od,"次方为:")
                                                        else:
                                                            if d<0:
                                                                print(oc+od,"次方为:")
                                                            elif d>0:
                                                                print(oc+"+"+od,"次方为:")
                                                            else:
                                                                print(oc,"次方为:")
                                                        print("Z(K)=",str(round(r**c/e**(d*arg),s))+"×"+str(round(e**pi,s)),end="")
                                                        if d>0:
                                                            print("^(-"+str(round(abs(d)*2,s))+"K)",end="")
                                                        else:
                                                            print("^("+str(round(abs(d)*2,s))+"K)",end="")
                                                        if c==0:
                                                            if sin(d*ln(r))==0:
                                                                if cos(d*ln(r))==1:
                                                                    print(",K∈Z")
                                                                else:
                                                                    print("×(-1),K∈Z")
                                                            elif sin(d*ln(r))>0:
                                                                print("×("+str(round(cos(d*ln(r)),s))+"+"+str(round(sin(d*ln(r)),s))+"i),K∈Z")
                                                            else:
                                                                print("×("+str(round(cos(d*ln(r)),s))+str(round(sin(d*ln(r)),s))+"i),K∈Z")
                                                        elif round(d*ln(r)+c*arg,s)==0:
                                                            print("×[cos("+str(round(c*2*pi,s))+"K)+isin("+str(round(c*2*pi,s))+"K)],K∈Z")
                                                        elif c>0:
                                                            print("×[cos("+str(round(d*ln(r)+c*arg,s))+"+"+str(round(c*2*pi,s))+"K)+isin("+str(round(d*ln(r)+c*arg,s))+"+"+str(round(c*2*pi,s))+"K)],K∈Z")
                                                        else:
                                                            print("×[cos("+str(round(d*ln(r)+c*arg,s))+str(round(c*2*pi,s))+"K)+isin("+str(round(d*ln(r)+c*arg,s))+str(round(c*2*pi,s))+"K)],K∈Z")
                                                        print("特别地,当K=0时:")
                                                        print("Z(0)= ",end="")
                                                        jga=round(_rn*_ac,s)
                                                        jgb=round(_rn*_as,s)
                                                        ojga=str(jga)
                                                        ojgb=str(jgb)+"i"
                                                        if jga==0:
                                                            print(ojgb)
                                                        else:
                                                            if jgb<0:
                                                                print(ojga+ojgb)
                                                            elif jgb>0:
                                                                print(ojga+"+"+ojgb)
                                                            else:
                                                                print(ojga)
                                            except:
                                                print("输入的复数模太大,无法计算,请重新输入模较小的复数")
                                    except:
                                        print("请重新输入d,d∈R*")
                                except:
                                    print("请重新输入c,c∈R")
                            except:
                                print("请重新输入b,b∈R")
                        except:
                            print("请重新输入a,a∈R")
                        print("—————————————————————————————————")
                    else:
                        print("  暂不支持"+"'"+modeson+"'"+"子模式")
                elif mode=="4":
                    print("——————复数Z=a+bi的n次方根求解——————")
                    print("—————————a,b∈R;n∈Z—————————")
                    a=input("a=")
                    b=input("b=")
                    n=input("n=")
                    try:
                        a=float(a)
                        try:
                            b=float(b)
                            try:
                                n=int(n)
                                try:
                                    print("—————————————————————————————————")
                                    oa=str(a)
                                    ob=str(b)+"i"
                                    if n!=0:
                                        n1=n
                                        n=abs(n)
                                        Dr=pow(a,2)+pow(b,2)
                                        if Dr==0:
                                            print("0","的",n1,"次方根为 0")
                                        else:
                                            if n1<0:
                                                a=a/Dr
                                                b=-1*(b/Dr)
                                            r=pow(Dr,0.5)
                                            arg=arccos(a/r)
                                            if b/r<0:
                                                arg=2*pi-arg
                                            if nan(pow(r,1/n)*cos((2*pi*(n-1)+arg)/n)) or nan(pow(r,1/n)*sin((2*pi*(n-1)+arg)/n))==True:
                                                print("输入的复数模太大或|n|太大,无法计算,请重新输入模较小的复数或较小的|n|")
                                            else:
                                                if a==0:
                                                    print(ob,"的",n1,"次方根为:")
                                                else:
                                                    if b<0:
                                                        print(oa+ob,"的",n1,"次方根为:")
                                                    elif b>0:
                                                        print(oa+"+"+ob,"的",n1,"次方根为:")
                                                    else:
                                                        print(oa,"的",n1,"次方根为:")
                                                rn=pow(r,1/n)
                                                if n!=1:
                                                    if round(arg,s)!=0:
                                                        if n%2==0:
                                                            if n/2==1:
                                                                print("Z(K+1)=",str(round(rn,s))+"×[cos("+str(round(pi,s))+"K+"+str(round(arg/2,s))+")+isin("+str(round(pi,s))+"K+"+str(round(arg/2,s))+")],K∈[0,"+str(n-1)+"]∩Z")
                                                            else:
                                                                print("Z(K+1)=",str(round(rn,s))+"×{cos[("+str(round(pi,s))+"K+"+str(round(arg/2,s))+")/"+str(int(n/2))+"]+isin[("+str(round(pi,s))+"K+"+str(round(arg/2,s))+")/"+str(int(n/2))+"]},K∈[0,"+str(n-1)+"]∩Z")
                                                        else:
                                                            print("Z(K+1)=",str(round(rn,s))+"×{cos[("+str(round(pi*2,s))+"K+"+str(round(arg,s))+")/"+str(int(n))+"]+isin[("+str(round(pi*2,s))+"K+"+str(round(arg,s))+")/"+str(int(n))+"]},K∈[0,"+str(n-1)+"]∩Z")
                                                    else:
                                                        if n%2==0:
                                                            if n/2==1:
                                                                print("Z(K+1)=",str(round(rn,s))+"×[cos("+str(round(pi,s))+"K)+isin("+str(round(pi,s))+"K)],K∈[0,"+str(n-1)+"]∩Z")
                                                            else:
                                                                print("Z(K+1)=",str(round(rn,s))+"×{cos[("+str(round(pi,s))+"K)/"+str(int(n/2))+"]+isin[("+str(round(pi,s))+"K)/"+str(int(n/2))+"]},K∈[0,"+str(n-1)+"]∩Z")
                                                        else:
                                                            print("Z(K+1)=",str(round(rn,s))+"×{cos[("+str(round(pi*2,s))+"K)/"+str(int(n))+"]+isin[("+str(round(pi*2,s))+"K)/"+str(int(n))+"]},K∈[0,"+str(n-1)+"]∩Z")
                                                bh=""
                                                if n>100:
                                                    print("即将输出",abs(n),"个结果,是否输出?")
                                                    bh=input("按回车继续输出,否则停止输出")
                                                if bh=="":
                                                    for k in range(0,n):
                                                        an=round(rn*cos((2*pi*k+arg)/n),s)
                                                        bn=round(rn*sin((2*pi*k+arg)/n),s)
                                                        oan=str(an)
                                                        obn=str(bn)+"i"
                                                        oZ="Z("+str(k+1)+")="
                                                        if an==0:
                                                            if bn==0:
                                                                print(oZ,0)
                                                            else:
                                                                print(oZ,obn)
                                                        else:
                                                            if bn<0:
                                                                print(oZ,oan+obn)
                                                            elif bn>0:
                                                                print(oZ,oan+"+"+obn)
                                                            else:
                                                                print(oZ,oan)
                                    else:
                                        if a==0:
                                            if b==0:
                                                print("0的0次方根为:","∞")
                                            else:
                                                print(ob,"的0次方根为:","∞")
                                        else:
                                            if b<0:
                                                print(oa+ob,"的0次方根为:","∞")
                                            elif b>0:
                                                print(oa+"+"+ob,"的0次方根为:","∞")
                                            else:
                                                print(oa,"的0次方根为:","∞")
                                except:
                                    print("输入的复数模太大或|n|太大,无法计算,请重新输入模较小的复数或较小的|n|")
                            except:
                                print("请重新输入n,n∈Z")
                        except:
                            print("请重新输入b,b∈R")
                    except:
                        print("请重新输入a,a∈R")
                    print("—————————————————————————————————")
                else:
                    print("暂不支持"+"'"+mode+"'"+"模式")
            print("感谢使用")
    except:
        print("仅支持保留[1,9]位小数")